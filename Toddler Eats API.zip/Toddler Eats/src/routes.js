const {
    tampilkanResepMakanBayi,
} = require('./handler');

const routes = [
    {
        method: 'GET',
        path: '/resep',
        handler: tampilkanResepMakanBayi,
      }
    ];

    module.exports = routes;