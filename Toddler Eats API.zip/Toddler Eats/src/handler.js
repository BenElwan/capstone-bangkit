const resepMakanBayi = require('./batita');

const tampilkanResepMakanBayi = (request, h) => {
  const { beratBadan, usia, frekuensiMakan } = request.query;

  if (!beratBadan || !usia || !frekuensiMakan) {
    const response = h
      .response({
        status: 'fail',
        message: 'Masukkan berat badan, usia, dan frekuensi makan bayi untuk menampilkan resep makan bayi',
      })
      .code(400);

    return response;
  }

  const filteredResep = resepMakanBayi.filter((resep) => {
    return resep.beratBadan === beratBadan && resep.usia === usia && resep.frekuensiMakan === frekuensiMakan;
  });

  if (filteredResep.length === 0) {
    const response = h
      .response({
        status: 'fail',
        message: 'Resep makan bayi tidak ditemukan untuk parameter yang diberikan',
      })
      .code(404);

    return response;
  }

  const dataResep = filteredResep.map((resep) => {
    return {
      id: resep.id,
      nama: resep.nama,
      foto: resep.foto,
      deskripsi: resep.deskripsi,
    };
  });

  const response = h
    .response({
      status: 'success',
      data: {
        resep: dataResep,
      },
    })
    .code(200);

  return response;
};


module.exports = {
tampilkanResepMakanBayi
};